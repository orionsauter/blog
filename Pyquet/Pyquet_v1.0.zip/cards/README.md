Card images from https://code.google.com/archive/p/vector-playing-cards/downloads
